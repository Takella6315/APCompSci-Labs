/* Starter file for JHU CTY AP CS Course Final Project */

interface YathzeeScoreCard
{
    void scoreHand(YahtzeeHand yahtzee, int game);
}
