/**
 * Unit1Lab_takel1s.java
 * The function of this program is print out a brief statement about myself using the new line character. The output should be:
 *  Hello All!
 *  My name is Teja Akella.
 *  I am 16 years old and my favorite movie is "Rush Hour 2"
 * @author Teja Akella
 */
package Unit1Lab;

public class Unit1Lab_takel1s {
    public static void main(String args[]){

        System.out.println("Hello All!\nMy name is Teja Akella.\nI am 16 years old and my favorite movie is \"Rush Hour 2\"");

    }
}
