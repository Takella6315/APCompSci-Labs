/**
 * This is the interface that defines the draw and get name methods
 * @author Teja Akella
 */
package Unit17.Unit17Assigment1;

public interface Drawable {
        String getName();
        void draw();
      }

